----------------
Helper Functions
----------------

.. currentmodule:: oslo.config.cfg

.. autofunction:: find_config_files
.. autofunction:: set_defaults
