--------------------
The ConfigOpts Class
--------------------

.. currentmodule:: oslo.config.cfg

.. autoclass:: ConfigOpts
   :members:
