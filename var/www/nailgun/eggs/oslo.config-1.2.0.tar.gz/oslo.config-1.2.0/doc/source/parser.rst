------------
File Parsing
------------

.. autoclass:: oslo.config.iniparser.BaseParser

.. autoclass:: oslo.config.cfg.ConfigParser
   :members: parse

.. autoclass:: oslo.config.cfg.MultiConfigParser
   :members: read, get
