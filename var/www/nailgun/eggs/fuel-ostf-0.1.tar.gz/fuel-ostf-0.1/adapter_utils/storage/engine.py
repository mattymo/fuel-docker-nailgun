# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright 2013 Mirantis, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


_ENGINE = None
_MAKER = None


def get_session(db_path):
    global _ENGINE
    global _MAKER

    if _MAKER is None:
        engine = get_engine(db_path)
        _MAKER = sessionmaker(bind=engine, autocommit=True,
                              expire_on_commit=False)

    session = _MAKER()
    return session


def get_engine(db_path):
    global _ENGINE

    if _ENGINE is None:
        _ENGINE = create_engine(db_path)

    return _ENGINE
