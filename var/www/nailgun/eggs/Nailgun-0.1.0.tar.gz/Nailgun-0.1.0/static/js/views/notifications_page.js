/*
 * Copyright 2013 Mirantis, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
**/

define(["utils","models","views/common","views/dialogs","text!templates/notifications/list.html"],function(t,e,i,n,s){var o=i.Page.extend({navbarActiveElement:null,breadcrumbsPath:[["home","#"],"notifications"],title:function(){return $.t("notifications_page.title")},template:_.template(s),templateHelpers:_.pick(t,"urlify"),events:{"click .new":"markAsRead","click .discover":"showNodeInfo"},markAsRead:function(t){var e=this.notifications.get($(t.currentTarget).data("id"));e.toJSON=function(){return _.pick(e.attributes,"id","status")},e.save({status:"read"}).done(_.bind(function(){this.notifications.trigger("sync")},this))},showNodeInfo:function(t){var i=$(t.currentTarget).data("node");if(i){var s=new e.Node({id:i});s.deferred=s.fetch();var o=new n.ShowNodeInfoDialog({node:s});this.registerSubView(o),o.render()}},initialize:function(t){_.defaults(this,t),this.notifications.on("sync",this.render,this)},render:function(){return this.$el.html(this.template(_.extend({notifications:this.notifications},this.templateHelpers))).i18n(),this}});return o});