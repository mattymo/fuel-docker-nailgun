/*
 * Copyright 2013 Mirantis, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
**/

define(["models","views/common","views/dialogs","text!templates/cluster/actions_tab.html"],function(e,t,i,n){var r=t.Tab.extend({template:_.template(n),events:{"click .rename-cluster-form .apply-name-btn":"applyNewClusterName","keydown .rename-cluster-form input":"onClusterNameInputKeydown","click .delete-cluster-form .delete-cluster-btn":"deleteCluster"},applyNewClusterName:function(){var e=$.trim(this.$(".rename-cluster-form input").val());if(e!=this.model.get("name")){var t=this.model.save({name:e},{patch:!0,wait:!0});if(t){var i=this.$(".rename-cluster-form input, .rename-cluster-form button");i.attr("disabled",!0),t.fail(_.bind(function(e){409==e.status&&this.model.trigger("invalid",this.model,{name:e.responseText})},this)).always(_.bind(function(){i.attr("disabled",!1)},this))}}},showValidationError:function(e,t){this.$(".alert-error").text(_.values(t).join("; ")).show()},onClusterNameInputKeydown:function(){this.$(".alert-error").hide()},deleteCluster:function(){var e=new i.RemoveClusterDialog({model:this.model});this.registerSubView(e),e.render()},initialize:function(e){_.defaults(this,e),this.model.on("change:name",this.render,this),this.model.on("invalid",this.showValidationError,this)},render:function(){return this.$el.html(this.template({cluster:this.model})).i18n(),this}});return r});