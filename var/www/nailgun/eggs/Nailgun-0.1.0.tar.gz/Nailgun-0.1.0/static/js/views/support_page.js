/*
 * Copyright 2013 Mirantis, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
**/

define(["views/common","models","text!templates/support/page.html"],function(e,s,t){var a=e.Page.extend({navbarActiveElement:"support",breadcrumbsPath:[["home","#"],"support"],title:function(){return $.t("support_page.title")},updateInterval:2e3,template:_.template(t),events:{"click .download-logs":"downloadLogs"},bindings:{".registration-link":{attributes:[{name:"href",observe:"key",onGet:function(e){return _.isUndefined(e)?"/":"http://fuel.mirantis.com/create-subscriber/?key="+e}}]}},scheduleUpdate:function(){var e=this.logsPackageTasks.findTask({name:"dump"});this.timeout&&this.timeout.clear(),!e||e.get("progress")<100?this.registerDeferred(this.timeout=$.timeout(this.updateInterval).done(_.bind(this.update,this))):this.render()},update:function(){var e=this.logsPackageTasks.findTask({name:"dump"});e&&this.registerDeferred(e.fetch().always(_.bind(this.scheduleUpdate,this)))},downloadLogs:function(){var e=new s.LogsPackage;this.logsPackageTasks.reset(),e.save({},{method:"PUT"}).always(_.bind(function(){this.logsPackageTasks.fetch().done(_.bind(this.scheduleUpdate,this))},this)),this.render(),this.scheduleUpdate(),this.$(".download-logs, .donwload-logs-link, .download-logs-error").addClass("hide"),this.$(".genereting-logs").removeClass("hide")},initialize:function(e){_.defaults(this,e),this.fuelKey=new s.FuelKey,this.fuelKey.fetch(),this.logsPackageTasks=new s.Tasks,this.logsPackageTasks.once("sync",this.checkCompletedTask,this),this.logsPackageTasks.deferred=this.logsPackageTasks.fetch()},checkCompletedTask:function(){this.logsPackageTasks.deferred=null;var e=this.logsPackageTasks.findTask({name:"dump"});e&&e.get("progress")<100?this.scheduleUpdate():this.render()},render:function(){return this.$el.html(this.template({tasks:this.logsPackageTasks})).i18n(),this.stickit(this.fuelKey),this}});return a});