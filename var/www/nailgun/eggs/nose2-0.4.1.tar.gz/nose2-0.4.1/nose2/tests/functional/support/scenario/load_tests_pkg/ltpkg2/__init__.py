def lt(a, b):
    return a < b
