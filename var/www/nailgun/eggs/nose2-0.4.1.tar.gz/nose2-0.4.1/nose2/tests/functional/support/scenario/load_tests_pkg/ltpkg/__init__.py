def gt(a, b):
    return a > b
