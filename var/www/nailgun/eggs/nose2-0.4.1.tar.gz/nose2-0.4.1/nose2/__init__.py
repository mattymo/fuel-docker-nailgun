from nose2.main import discover, main
