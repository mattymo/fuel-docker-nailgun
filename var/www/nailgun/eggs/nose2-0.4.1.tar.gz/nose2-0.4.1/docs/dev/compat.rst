============
nose2.compat
============

.. automodule :: nose2.compat
   :members:
