===========================
Loader: load_tests protocol
===========================

.. autoplugin :: nose2.plugins.loader.loadtests.LoadTestsLoader
