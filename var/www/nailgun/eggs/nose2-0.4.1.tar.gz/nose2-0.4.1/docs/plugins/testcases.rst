==================
Loader: Test Cases
==================

.. autoplugin :: nose2.plugins.loader.testcases.TestCaseLoader
