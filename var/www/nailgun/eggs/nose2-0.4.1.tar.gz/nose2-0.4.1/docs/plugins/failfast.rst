=========================================
Stopping After the First Error or Failure
=========================================

.. autoplugin :: nose2.plugins.failfast.FailFast
