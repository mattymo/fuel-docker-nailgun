======================
Capturing log messages
======================

.. todo ::

   Document all the things.


.. autoplugin :: nose2.plugins.logcapture.LogCapture
