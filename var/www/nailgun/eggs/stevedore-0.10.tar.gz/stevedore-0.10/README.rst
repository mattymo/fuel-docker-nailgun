stevedore
=========

Manage dynamic plugins for Python applications

See http://stevedore.readthedocs.org for the full documentation.
