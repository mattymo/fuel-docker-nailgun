Python bindings to the Murano API
=====================
This is a client library for Murano built on the Murano API. It
provides a Python API (the ``muranoclient`` module) and a command-line tool
(``murano``).

SEE ALSO
--------
* `Murano <http://murano.mirantis.com>`__
