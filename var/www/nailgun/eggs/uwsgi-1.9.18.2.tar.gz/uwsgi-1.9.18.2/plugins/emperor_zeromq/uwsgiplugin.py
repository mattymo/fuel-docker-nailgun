
NAME='emperor_zeromq'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['emperor_zeromq']
