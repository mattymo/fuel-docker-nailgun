NAME='libffi'
CFLAGS=[]
LDFLAGS=[]
LIBS=['-lffi']
GCC_LIST=['libffi']
