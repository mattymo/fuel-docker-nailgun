hacking
=======

hacking is a set of flake8 plugins to test or enforce the more stringent
style guidelines that the OpenStack project operates under.

Contents
--------

.. toctree::
   :maxdepth: 1

   api/autoindex

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

